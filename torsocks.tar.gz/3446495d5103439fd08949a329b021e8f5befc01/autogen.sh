#!/bin/sh

set -x

if [ ! -e config ]; then
	mkdir config
fi

autoreconf -i
